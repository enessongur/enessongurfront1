function karşılamaEkranıGöster() {
    // Kullanıcıdan ismi al
    var isim = prompt("Merhaba! Adınız nedir?");

    // Anlık tarih ve saat bilgisini al
    var simdikiZaman = new Date();

    // Karşılama ekranını oluştur
    var karşılamaEkranı = `
        Merhaba, ${isim}!

        Bugün ${gunAdiAl(simdikiZaman.getDay())}'dir.
        Şu an saat ${simdikiZaman.getHours()}:${simdikiZaman.getMinutes()}.

        Hoş geldin!
    `;

    // Karşılama ekranını göster
    alert(karşılamaEkranı);
}

function gunAdiAl(gunIndex) {
    var gunler = ["Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi"];
    return gunler[gunIndex];
}

// Programı başlat
karşılamaEkranıGöster();